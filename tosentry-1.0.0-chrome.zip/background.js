var background=(function(){"use strict";var d,h;function f(e){return e==null||typeof e=="function"?{main:e}:e}const w="https://api.groq.com/openai/v1/chat/completions",k="llama-3.3-70b-versatile",v=f(()=>{chrome.runtime.onMessage.addListener((e,o,n)=>((async()=>{switch(e.type){case"ANALYZE_TOS":{const s=await b(e.text,e.apiKey);n(s);break}case"SAVE_API_KEY":{await chrome.storage.local.set({groqApiKey:e.apiKey}),n({success:!0});break}case"GET_API_KEY":{const s=await chrome.storage.local.get("groqApiKey");n({apiKey:s.groqApiKey||""});break}default:n({success:!1,error:"Unknown message type"})}})(),!0))});async function b(e,o){var m,g,y;if(!o||o.trim()==="")return{success:!1,error:"No Groq API key provided. Add your key in the extension settings."};const n=e.length>2e4?e.substring(0,2e4)+`

[...document truncated for analysis...]`:e,s=`You are a legal expert specialising in consumer rights and digital privacy. 
Your task is to analyse Terms of Service, Privacy Policies, and similar legal agreements.
You MUST respond with valid JSON only — no markdown, no preamble, no explanation outside the JSON.`,P=`Analyse this legal agreement and identify every significant concern for the end user.

Respond ONLY with a JSON object matching this exact schema:
{
  "summary": "2-3 sentence plain-English overview of what this agreement covers and its overall risk level",
  "overallRisk": "critical|high|medium|low",
  "risks": [
    {
      "title": "Short descriptive title (4-7 words)",
      "severity": "critical|high|medium|low",
      "explanation": "2-3 sentences explaining why this matters to a regular user in plain English",
      "quote": "Optional: exact short quote from the document that triggered this concern (max 100 chars)"
    }
  ]
}

Severity guide:
- critical: Violates fundamental rights, enables data selling, eliminates all legal recourse
- high: Significant privacy risk, one-sided arbitration, irrevocable IP rights, account termination without cause
- medium: Auto-renewal, broad data sharing, long retention, unilateral term changes
- low: Tracking cookies, targeted ads, minor restrictions

Focus on (in this order):
1. Data selling or sharing with third parties
2. Arbitration clauses and class action waivers
3. Privacy policy concerns (what data is collected, how long retained)
4. IP/content ownership claims
5. Financial gotchas (auto-renewal, no-refund)
6. Ability to terminate your account arbitrarily
7. Any other clauses that disproportionately favour the company

Agreement text:
---
${n}
---`;try{const r=await fetch(w,{method:"POST",headers:{Authorization:`Bearer ${o}`,"Content-Type":"application/json"},body:JSON.stringify({model:k,messages:[{role:"system",content:s},{role:"user",content:P}],temperature:.1,max_tokens:3e3,response_format:{type:"json_object"}})});if(!r.ok){const t=await r.text();return console.error("[ToSentry] Groq API error:",t),r.status===401?{success:!1,error:"Invalid Groq API key. Please check your key in settings."}:r.status===429?{success:!1,error:"Groq rate limit hit. Please wait a moment and try again."}:{success:!1,error:`API error ${r.status}: ${r.statusText}`}}const l=(y=(g=(m=(await r.json()).choices)==null?void 0:m[0])==null?void 0:g.message)==null?void 0:y.content;if(!l)return{success:!1,error:"Empty response from Groq API."};let p;try{const t=JSON.parse(l);p={summary:t.summary||"Analysis complete.",overallRisk:u(t.overallRisk),risks:(t.risks||[]).map(i=>({title:i.title||"Unnamed risk",severity:u(i.severity),explanation:i.explanation||"",quote:i.quote||void 0})),analyzedAt:Date.now()}}catch(t){return console.error("[ToSentry] JSON parse error:",t,l),{success:!1,error:"Could not parse AI response. Please try again."}}return{success:!0,analysis:p}}catch(r){return console.error("[ToSentry] Network error:",r),{success:!1,error:"Network error reaching Groq. Check your internet connection."}}}function u(e){return["critical","high","medium","low"].includes(e)?e:"medium"}function S(){}((h=(d=globalThis.browser)==null?void 0:d.runtime)==null?void 0:h.id)==null?globalThis.chrome:globalThis.browser;function a(e,...o){}const A={debug:(...e)=>a(console.debug,...e),log:(...e)=>a(console.log,...e),warn:(...e)=>a(console.warn,...e),error:(...e)=>a(console.error,...e)};let c;try{c=v.main(),c instanceof Promise&&console.warn("The background's main() function return a promise, but it must be synchronous")}catch(e){throw A.error("The background crashed on startup!"),e}return c})();
background;
